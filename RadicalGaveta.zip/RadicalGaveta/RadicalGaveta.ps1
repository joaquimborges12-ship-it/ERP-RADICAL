﻿# ==========================================================================
#  Radical Gaveta  -  abre a gaveta de dinheiro ligada na impressora térmica
#  Fica ligado escondido neste computador e só atende o sistema Radical Motos.
#  Ele NÃO mexe em dados do sistema: só manda o sinal de "abrir" para a impressora.
# ==========================================================================
$VERSAO = '1.0'
$PORTA  = 17788
$pasta  = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgArq = Join-Path $pasta 'config.txt'
$logArq = Join-Path $pasta 'registro.txt'

# só estes sites podem pedir para abrir a gaveta
$ORIGENS = @('https://radicalmotos.app.br', 'https://www.radicalmotos.app.br', 'https://joaquimborges12-ship-it.github.io')

# não deixa abrir dois ao mesmo tempo
$criado = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\RadicalGaveta', [ref]$criado)
if(-not $criado){ exit }

function Registrar($txt){
  try{
    if((Test-Path $logArq) -and (Get-Item $logArq).Length -gt 300KB){ Remove-Item $logArq -Force }
    Add-Content -Path $logArq -Value ((Get-Date -Format 'dd/MM/yyyy HH:mm:ss') + '  ' + $txt) -Encoding UTF8
  }catch{}
}

# configuração (config.txt):  impressora=MDK-082   pino=0
function LerConfig(){
  $c = @{ impressora = ''; pino = '0' }
  if(Test-Path $cfgArq){
    foreach($l in (Get-Content $cfgArq -Encoding UTF8)){
      if($l -match '^\s*([a-zA-Z]+)\s*=\s*(.*?)\s*$'){ $c[$matches[1].ToLower()] = $matches[2] }
    }
  }
  return $c
}

Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class RmGavetaRaw {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public class DOCINFO {
    [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
  }
  [DllImport("winspool.drv", EntryPoint = "OpenPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern bool OpenPrinter(string nome, out IntPtr h, IntPtr d);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool ClosePrinter(IntPtr h);
  [DllImport("winspool.drv", EntryPoint = "StartDocPrinterW", SetLastError = true, CharSet = CharSet.Unicode)]
  static extern int StartDocPrinter(IntPtr h, int nivel, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFO di);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndDocPrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool StartPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool EndPagePrinter(IntPtr h);
  [DllImport("winspool.drv", SetLastError = true)] static extern bool WritePrinter(IntPtr h, byte[] b, int n, out int escritos);
  public static string Enviar(string impressora, byte[] dados){
    IntPtr h;
    if(!OpenPrinter(impressora, out h, IntPtr.Zero)) return "nao consegui abrir a impressora (erro " + Marshal.GetLastWin32Error() + ")";
    try{
      DOCINFO di = new DOCINFO(); di.pDocName = "Radical Gaveta"; di.pDataType = "RAW";
      if(StartDocPrinter(h, 1, di) == 0) return "a impressora recusou (erro " + Marshal.GetLastWin32Error() + ")";
      try{
        StartPagePrinter(h);
        int n; bool ok = WritePrinter(h, dados, dados.Length, out n);
        EndPagePrinter(h);
        if(!ok || n != dados.Length) return "falhou ao enviar (erro " + Marshal.GetLastWin32Error() + ")";
      } finally { EndDocPrinter(h); }
    } finally { ClosePrinter(h); }
    return "";
  }
}
'@

function ListaImpressoras(){
  $l = @(); foreach($p in [System.Drawing.Printing.PrinterSettings]::InstalledPrinters){ $l += [string]$p }; return $l
}
# acha a impressora: a do config.txt, senão a que tiver MDK / Tomate no nome
function AcharImpressora(){
  $cfg = LerConfig; $todas = ListaImpressoras
  if($cfg.impressora){ $x = $todas | Where-Object { $_ -eq $cfg.impressora } | Select-Object -First 1; if($x){ return $x } }
  foreach($chave in @('MDK', 'Tomate', 'TOMATE')){
    $x = $todas | Where-Object { $_ -like "*$chave*" } | Select-Object -First 1; if($x){ return $x }
  }
  return ''
}

function AbrirGaveta(){
  $imp = AcharImpressora
  if(-not $imp){ return @{ ok = $false; erro = 'Não achei a impressora MDK-082 neste computador.' } }
  $cfg = LerConfig
  $pino = 0; if($cfg.pino -eq '1'){ $pino = 1 }
  # ESC p m t1 t2  -> pulso na gaveta (pino 2 = 0, pino 5 = 1)
  [byte[]]$cmd = 0x1B, 0x70, $pino, 0x19, 0xFA
  $erro = [RmGavetaRaw]::Enviar($imp, $cmd)
  if($erro){ return @{ ok = $false; erro = $erro; impressora = $imp } }
  return @{ ok = $true; impressora = $imp }
}

function Json($o){ return (ConvertTo-Json $o -Compress) }

function Responder($stream, $codigo, $corpo, $origem){
  $txt = @{ 200 = 'OK'; 204 = 'No Content'; 403 = 'Forbidden'; 404 = 'Not Found'; 500 = 'Error' }[$codigo]
  $b = [System.Text.Encoding]::UTF8.GetBytes([string]$corpo)
  $h = "HTTP/1.1 $codigo $txt`r`n"
  if($origem){
    $h += "Access-Control-Allow-Origin: $origem`r`nVary: Origin`r`n"
    $h += "Access-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Headers: Content-Type`r`n"
    $h += "Access-Control-Allow-Private-Network: true`r`nAccess-Control-Max-Age: 600`r`n"
  }
  $h += "Content-Type: application/json; charset=utf-8`r`nCache-Control: no-store`r`nContent-Length: $($b.Length)`r`nConnection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($h)
  $stream.Write($hb, 0, $hb.Length); if($b.Length){ $stream.Write($b, 0, $b.Length) }; $stream.Flush()
}

function Atender($cli){
  $cli.ReceiveTimeout = 3000; $cli.SendTimeout = 3000
  $s = $cli.GetStream()
  # lê o cabeçalho do pedido
  $buf = New-Object byte[] 8192; $tot = 0; $cab = ''
  while($tot -lt $buf.Length){
    $n = $s.Read($buf, $tot, $buf.Length - $tot); if($n -le 0){ break }; $tot += $n
    $cab = [System.Text.Encoding]::ASCII.GetString($buf, 0, $tot); if($cab.Contains("`r`n`r`n")){ break }
  }
  if(-not $cab){ return }
  $linhas = $cab.Split("`n")
  $p = $linhas[0].Trim().Split(' '); if($p.Length -lt 2){ return }
  $metodo = $p[0].ToUpper(); $caminho = $p[1].Split('?')[0].ToLower()
  $origem = ''
  foreach($l in $linhas){ if($l -match '^\s*Origin\s*:\s*(.+?)\s*$'){ $origem = $matches[1] } }
  $permitida = ''
  if($origem){
    if($ORIGENS -contains $origem.ToLower()){ $permitida = $origem }
    else { Registrar "Recusado: pedido veio de $origem"; Responder $s 403 (Json @{ ok = $false; erro = 'site não autorizado' }) ''; return }
  }
  if($metodo -eq 'OPTIONS'){ Responder $s 204 '' $permitida; return }
  if($caminho -eq '/status'){
    $imp = AcharImpressora
    Responder $s 200 (Json @{ ok = $true; programa = 'Radical Gaveta'; versao = $VERSAO; impressora = $imp; achou = [bool]$imp; impressoras = @(ListaImpressoras) }) $permitida
    return
  }
  if($caminho -eq '/abrir' -and $metodo -eq 'POST'){
    $r = AbrirGaveta
    if($r.ok){ Registrar "Gaveta aberta ($($r.impressora))" } else { Registrar "ERRO ao abrir: $($r.erro)" }
    $r.versao = $VERSAO
    Responder $s 200 (Json $r) $permitida
    return
  }
  Responder $s 404 (Json @{ ok = $false; erro = 'endereço não existe' }) $permitida
}

# --- liga o "ouvido" só neste computador (127.0.0.1), ninguém de fora da loja alcança ---
try{
  $ouvinte = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $PORTA)
  $ouvinte.Start()
}catch{
  Registrar "Não consegui ligar na porta $PORTA : $($_.Exception.Message)"; exit
}
Registrar "Radical Gaveta $VERSAO ligado (porta $PORTA). Impressora: $(AcharImpressora)"
while($true){
  $cli = $null
  try{
    $cli = $ouvinte.AcceptTcpClient()
    Atender $cli
  }catch{
    Registrar "Erro: $($_.Exception.Message)"
  }finally{
    if($cli){ try{ $cli.Close() }catch{} }
  }
}
