@echo off
title Desinstalar Radical Gaveta
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desinstalar.ps1"
