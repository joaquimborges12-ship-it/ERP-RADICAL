﻿# Remove o Radical Gaveta deste computador
$dest = Join-Path $env:LOCALAPPDATA 'RadicalGaveta'
try{
  Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*RadicalGaveta.ps1*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }
}catch{}
Start-Sleep -Milliseconds 800
Remove-Item (Join-Path ([Environment]::GetFolderPath('Startup')) 'Radical Gaveta.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host '  Radical Gaveta removido deste computador.' -ForegroundColor Green
Write-Host '  (O sistema continua funcionando normal; só o botão da gaveta para de abrir aqui.)'
Write-Host ''
Read-Host '  Aperte Enter para fechar'
