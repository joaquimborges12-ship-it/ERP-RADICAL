@echo off
title Instalar Radical Gaveta
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
