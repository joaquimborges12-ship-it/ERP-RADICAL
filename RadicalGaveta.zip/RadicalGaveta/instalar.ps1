﻿# Instalador do Radical Gaveta (não precisa ser administrador)
$ErrorActionPreference = 'Stop'
$origem = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest   = Join-Path $env:LOCALAPPDATA 'RadicalGaveta'
$ps     = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$args1  = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\RadicalGaveta.ps1`""

Write-Host ''
Write-Host '  ==============================================' -ForegroundColor Green
Write-Host '     RADICAL GAVETA - instalação' -ForegroundColor Green
Write-Host '  ==============================================' -ForegroundColor Green
Write-Host ''

function Parar(){
  try{
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*RadicalGaveta.ps1*' } | ForEach-Object { Invoke-CimMethod -InputObject $_ -MethodName Terminate | Out-Null }
  }catch{}
}

try{
  Write-Host '  1) Copiando os arquivos...'
  Parar; Start-Sleep -Milliseconds 800
  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  Copy-Item (Join-Path $origem 'RadicalGaveta.ps1') $dest -Force
  Copy-Item (Join-Path $origem 'desinstalar.ps1') $dest -Force -ErrorAction SilentlyContinue
  Get-ChildItem $dest | Unblock-File -ErrorAction SilentlyContinue

  Write-Host '  2) Fazendo ele ligar sozinho quando o Windows iniciar...'
  $startup = [Environment]::GetFolderPath('Startup')
  $sh = New-Object -ComObject WScript.Shell
  $lnk = $sh.CreateShortcut((Join-Path $startup 'Radical Gaveta.lnk'))
  $lnk.TargetPath = $ps; $lnk.Arguments = $args1; $lnk.WorkingDirectory = $dest; $lnk.WindowStyle = 7
  $lnk.Description = 'Abre a gaveta de dinheiro para o sistema Radical Motos'
  $lnk.Save()

  Write-Host '  3) Ligando agora...'
  Start-Process -FilePath $ps -ArgumentList $args1 -WindowStyle Hidden
  $st = $null
  for($i = 0; $i -lt 15 -and -not $st; $i++){
    Start-Sleep -Seconds 1
    try{ $st = Invoke-RestMethod -Uri 'http://127.0.0.1:17788/status' -TimeoutSec 2 }catch{}
  }
  if(-not $st){ throw 'O programa não respondeu. Veja o arquivo registro.txt na pasta ' + $dest }

  if(-not $st.achou){
    Write-Host ''
    Write-Host '  Não achei a impressora MDK-082 pelo nome. Impressoras deste computador:' -ForegroundColor Yellow
    $lista = @($st.impressoras)
    for($i = 0; $i -lt $lista.Count; $i++){ Write-Host ("     " + ($i + 1) + ') ' + $lista[$i]) }
    $n = Read-Host '  Digite o NÚMERO da impressora térmica (Tomate) e aperte Enter'
    $esc = $lista[[int]$n - 1]
    if(-not $esc){ throw 'Número inválido. Rode o instalador de novo.' }
    Set-Content -Path (Join-Path $dest 'config.txt') -Value @("impressora=$esc", 'pino=0') -Encoding UTF8
    $st = Invoke-RestMethod -Uri 'http://127.0.0.1:17788/status' -TimeoutSec 3
  }

  Write-Host ''
  Write-Host ('  PRONTO! Radical Gaveta ligado. Impressora: ' + $st.impressora) -ForegroundColor Green
  Write-Host ''
  $t = Read-Host '  Quer testar agora? A gaveta vai abrir. (S/N)'
  if($t -match '^[sS]'){
    $r = Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:17788/abrir' -TimeoutSec 5
    if($r.ok){ Write-Host '  Sinal enviado! A gaveta abriu?' -ForegroundColor Green }
    else { Write-Host ('  Deu erro: ' + $r.erro) -ForegroundColor Red }
    Write-Host '  Se NÃO abriu: confira o cabo da gaveta na entrada "DK" / "CASH DRAWER" da impressora.'
  }
  Write-Host ''
  Write-Host '  Agora abra o sistema no Chrome. Na primeira vez o Chrome pode perguntar'
  Write-Host '  se o site pode acessar "apps e serviços deste dispositivo": clique em PERMITIR.'
}catch{
  Write-Host ''
  Write-Host ('  ERRO: ' + $_.Exception.Message) -ForegroundColor Red
}
Write-Host ''
Read-Host '  Aperte Enter para fechar'
